import { Container } from "@mantine/core";

const Landing = () => {
  return (
    <Container>
      <h1>Welcome to the homepage. Anyone can see this page</h1>
    </Container>
  );
};

export default Landing;
